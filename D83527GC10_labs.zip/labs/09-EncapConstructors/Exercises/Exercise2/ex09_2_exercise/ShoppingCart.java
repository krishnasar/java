package ex09_2_exercise;


public class ShoppingCart {

    public static void main(String args[]) {
        // Declare, instantiate, and initialize a Customer object



	// Print the customer object name

        
    }
}
