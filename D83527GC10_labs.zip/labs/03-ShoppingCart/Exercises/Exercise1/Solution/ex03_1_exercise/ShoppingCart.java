package ex03_1_exercise;

public class ShoppingCart {
    public static void main (String[] args){
        System.out.println("Welcome to the Shopping Cart!");    
    }    
}
