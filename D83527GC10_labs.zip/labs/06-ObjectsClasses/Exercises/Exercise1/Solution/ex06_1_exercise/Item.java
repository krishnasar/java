
package ex06_1_exercise;

public class Item {

        public int itemID;
        public String desc;
        public double price;
        public int quantity;
        
}


