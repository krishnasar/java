Exercise 11-3

In the ShoppingCart class:
1.  Code the displayTotal method.  Use a standard for loop to 
      iterate through the items array.
2.  If the current item is out of stock (call isOutOfStock method of 
      the item), skip to the next loop iteration.
3.  If it is not out of stock, add the item price to a total variable 
      that you declare and initialize prior to the for loop.
4.  Print the Shopping Cart total with a suitable label.