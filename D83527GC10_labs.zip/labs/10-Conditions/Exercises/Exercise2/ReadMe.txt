Exercise 10-2

In the Order class:
1. Examine the existing code.
2. Code the calcDiscount method to determine discount for each 
     custType. 
     - Nonprofits get a 10% discount if their order is > 900, 
       otherwise it's 5%
     - Private types get 7% if order is > 900, otherwise no discount.
     - Corporate types get 8% if order < 500, otherwise they get 5%.
     - Use nested and chained if statement

In the ShoppingCart class:
3. Examine the code.  This class needs no modification.
4. Run the ShoppingCart to test the order.calcDiscount method. 